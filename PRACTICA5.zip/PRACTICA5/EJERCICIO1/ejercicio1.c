#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
	char frase[80]; 
	char *sepa;
	printf("Ingrese la frase deseada: ");
	gets(frase);
	sepa=strtok(frase," ");
	while(sepa!=NULL){
		printf("%s\n",sepa);
		sepa=strtok(NULL," ");
	}
	system("pause");
	return 0;
}
