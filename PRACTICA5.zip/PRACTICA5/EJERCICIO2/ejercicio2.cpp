#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
	char cadena[200];
    int i;
    printf("Introduce una cadena de texto: ");
    gets(cadena);
    i=strlen(cadena);
    printf("La cadena al reves es: ");
    for (i; i>=0; i--){
        printf("%c", cadena[i]);
    }
    printf("\n");
	system("pause");
	return 0;
}
