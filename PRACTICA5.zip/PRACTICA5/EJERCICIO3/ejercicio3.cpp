#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
	char lista[80];
	int x,a=0,e=0,i=0,o=0,u=0,I;
	printf("Introdusca la frase: ");
	gets(lista);
	x=strlen(lista);
	for (I=0; I<x; I++){
		if(lista[I]=='a'){a++;}
		if(lista[I]=='e'){e++;}
		if(lista[I]=='i'){i++;}
		if(lista[I]=='o'){o++;}
		if(lista[I]=='u'){u++;}
	}
	printf("a= %d\n",a);
	printf("e= %d\n",e);
	printf("i= %d\n",i);
	printf("o= %d\n",o);
	printf("u= %d\n",u);
	system("pause");
	return 0;
}
