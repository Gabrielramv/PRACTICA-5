#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]){
        int i=0;
        char linea[20], cad1[20], cad2[20], cad3[20];
        char *mes;
        char *token;
        char *token1;
        char *token2;
        char *pt;
        printf("Ingrese una fecha con formato (dd/mm/aa):\n");
        gets(linea);
        strcat (linea,"/");
        char *fin= strchr (linea,'/');
        char *fin3= strrchr(linea,'/');
        token=linea;
        token= strtok(linea, "/");
        token= strtok(NULL,"/");
        char *inicio2= token;
        char *fin2= strtok(NULL,"/");
        token=linea;
        
        for (pt=token;pt<fin;pt++){
                cad1[i]=*pt;
                i++;
        }
        cad1[i]='\0';
                
        i=0;
    for (pt=inicio2;pt<fin2;pt++){
        cad2[i]=*pt;
            i++;
    }
    cad2[i]='\0';
    
        if (cad2[0]=='0' && cad2[1]=='1'){
                mes="Enero";
        }else
        if (cad2[0]=='0' && cad2[1]=='2'){
                mes="Febrero";
        }else
        if (cad2[0]=='0' && cad2[1]=='3'){
                mes="Marzo";
        }else
        if (cad2[0]=='0' && cad2[1]=='4'){
                mes="Abril";
        }else
        if (cad2[0]=='0' && cad2[1]=='5'){
                mes="Mayo";
        }else
        if (cad2[0]=='0' && cad2[1]=='6'){
                mes="Junio";
        }else
        if (cad2[0]=='0' && cad2[1]=='7'){
                mes="Julio";
        }else
        if (cad2[0]=='0' && cad2[1]=='8'){
                mes="Agosto";
        }else
        if (cad2[0]=='0' && cad2[1]=='9'){
                mes="Septiembre";
        }else
        if (cad2[0]=='1' && cad2[1]=='0'){
                mes="Octubre";
        }else
        if (cad2[0]=='1' && cad2[1]=='1'){
                mes="Noviembre";
        }else
        if (cad2[0]=='1' && cad2[1]=='2'){
                mes="Diciembre";
        }else{
                printf ("�MES INVALIDO, FIN, INGRESE UN MES VALIDO!");
        }

        i=0;
    for (pt=fin2;pt<fin3;pt++){
        cad3[i]=*pt;
            i++;
    }
        cad3[i]='\0';
        printf ("\n%s de %s de 20%s\n",cad1,mes,cad3);  
        printf ("\n");
        system("pause");
        return 0;
}
	return 0;
}
